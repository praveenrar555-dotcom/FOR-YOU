# For Kritika 💌

Ek personal romantic web app — timeline, letters, reasons jar, gallery, quiz,
countdown, future plans aur ek surprise button.

## 1. Content edit karo (sabse important step)

`src/content.js` file kholo aur apna sara personal content daalo:
- `LOGIN.username` aur `LOGIN.password` — apna login set karo
- `TIMELINE`, `LETTERS`, `REASONS`, `QUIZ`, `FUTURE_PLANS`, `COUNTDOWN` — apni
  kahani, letters, reasons, quiz questions, plans aur target date daalo
- `GALLERY` — apni photos ke URLs daalo (Firebase Storage ya kisi bhi image
  hosting se link le sakte ho)

## 2. Local pe test karo

```bash
npm install
npm run dev
```

Browser mein `http://localhost:5173` khol ke dekh lo sab kuch sahi lag raha hai.

## 3. GitHub pe push karo

```bash
git init
git add .
git commit -m "For Kritika app"
git branch -M main
git remote add origin <tumhara-github-repo-url>
git push -u origin main
```

Agar GitHub pe naya repo banana hai to github.com pe "New repository" bana lo,
phir upar wala URL use karo.

## 4. Render pe deploy karo

1. [render.com](https://render.com) pe login karo (GitHub se sign in kar sakte ho)
2. **New +** → **Static Site** choose karo
3. Apna GitHub repo connect karo
4. Settings:
   - **Build Command:** `npm install && npm run build`
   - **Publish Directory:** `dist`
5. **Create Static Site** dabao — kuch minute mein live ho jayega

## 5. Firebase (optional — photos/data store karne ke liye)

Agar photos ya data cloud pe store karna hai (taaki content.js mein hardcode
na karna pade):

1. [console.firebase.google.com](https://console.firebase.google.com) pe naya
   project banao
2. **Storage** enable karo (photos ke liye) ya **Firestore** (agar dynamic
   data chahiye, jaise naye letters add karna bina redeploy kiye)
3. Project Settings se apna Firebase config copy karo
4. `src/firebase.js` file banao aur wahan config paste karo:

```js
import { initializeApp } from "firebase/app"
import { getStorage } from "firebase/storage"

const firebaseConfig = {
  // apna config yahan paste karo
}

const app = initializeApp(firebaseConfig)
export const storage = getStorage(app)
```

Firebase already `package.json` mein dependency ke roop mein add hai, isliye
`npm install` ke baad seedha use kar sakte ho.

## Notes

- Login abhi ek simple client-side check hai (username/password `content.js`
  mein hardcoded) — yeh kisi serious security ke liye nahi hai, bas ek chhota
  personal gate hai.
- Design tokens (colors, fonts) `src/styles.css` ke top pe `:root` mein hain,
  agar palette change karni ho to wahan se karo.
