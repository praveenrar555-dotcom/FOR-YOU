// =====================================================================
// YEH FILE APNI MARZI SE EDIT KARO — sab personal content yahin hai
// =====================================================================

export const LOGIN = {
  username: "kritika",      // yahan apna chosen username daalo
  password: "changeme123",  // yahan fixed password daalo
}

export const PARTNER_NAME = "Kritika"

// --- Timeline: your story so far ---
export const TIMELINE = [
  { date: "Jab pehli baar mile", text: "Yahan apna pehla moment likho..." },
  { date: "Pehli baat cheet", text: "Wo pehli conversation kaisi thi..." },
  { date: "Pehla 'I love you'", text: "Wo pal jab dil ne keh diya..." },
  { date: "Aaj", text: "Aur ab, har din tumhare saath..." },
]

// --- Reasons jar: pool of reasons, one shown randomly each visit ---
export const REASONS = [
  "Kyunki tumhari muskaan se mera din ban jaata hai.",
  "Kyunki tum meri sabse achi dost bhi ho.",
  "Kyunki tumhare saath sab kuch simple lagta hai.",
  "Kyunki tum meri sabse badi taqat ho.",
  "Yahan aur reasons add karo...",
]

// --- Love letters / daily notes ---
export const LETTERS = [
  { title: "Letter 1", body: "Yahan apna pehla letter likho, jitna chaho utna lamba..." },
  { title: "Letter 2", body: "Doosra letter yahan..." },
]

// --- Countdown target (edit date/time and label) ---
export const COUNTDOWN = {
  label: "Hamari agli mulaqat tak",
  targetDate: "2026-12-31T00:00:00", // ISO format
}

// --- Quiz: how well do you know me ---
export const QUIZ = [
  {
    question: "Mera favorite khaana kya hai?",
    options: ["Option A", "Option B", "Option C"],
    correctIndex: 0,
  },
  {
    question: "Mujhe sabse zyada kis cheez se dar lagta hai?",
    options: ["Option A", "Option B", "Option C"],
    correctIndex: 1,
  },
]

// --- Future plans board ---
export const FUTURE_PLANS = [
  { title: "Ek trip jo saath karenge", detail: "Kahan jaana hai likho..." },
  { title: "Ek sapna jo poora karna hai", detail: "Detail likho..." },
]

// --- Gallery: replace src with your own image URLs or import local images ---
export const GALLERY = [
  // { src: "/images/photo1.jpg", caption: "Yeh din yaad hai?" },
]

// --- Playlist: Spotify/YouTube embed links ---
export const PLAYLIST_EMBED_URL = "" // e.g. Spotify embed iframe src
