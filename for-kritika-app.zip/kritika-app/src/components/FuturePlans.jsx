import { FUTURE_PLANS } from '../content.js'

export default function FuturePlans() {
  return (
    <section className="section section-blush" id="plans">
      <p className="section-eyebrow">Aage kya</p>
      <h2>Kuch sapne jo saath dekhne hain</h2>
      <div className="plans-grid">
        {FUTURE_PLANS.map((plan, i) => (
          <div className="plan-card" key={i}>
            <h3>{plan.title}</h3>
            <p>{plan.detail}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
