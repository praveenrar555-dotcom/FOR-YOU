import { useState } from 'react'
import { LETTERS } from '../content.js'

export default function Letters() {
  const [openIndex, setOpenIndex] = useState(null)

  return (
    <section className="section section-dark" id="letters">
      <p className="section-eyebrow">Letters</p>
      <h2>Kuch likha hai tumhare liye</h2>
      <div className="letters-grid">
        {LETTERS.map((letter, i) => (
          <button
            key={i}
            className={`letter-envelope ${openIndex === i ? 'is-open' : ''}`}
            onClick={() => setOpenIndex(openIndex === i ? null : i)}
          >
            <span className="letter-title">{letter.title}</span>
            {openIndex === i && <p className="letter-body">{letter.body}</p>}
          </button>
        ))}
      </div>
    </section>
  )
}
