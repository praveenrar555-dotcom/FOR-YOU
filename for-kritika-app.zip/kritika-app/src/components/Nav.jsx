const SECTIONS = [
  { id: 'timeline', label: 'Kahani' },
  { id: 'letters', label: 'Letters' },
  { id: 'reasons', label: 'Reasons' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'quiz', label: 'Quiz' },
  { id: 'countdown', label: 'Countdown' },
  { id: 'plans', label: 'Plans' },
  { id: 'surprise', label: 'Surprise' },
]

export default function Nav() {
  function scrollTo(id) {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <nav className="top-nav">
      <span className="nav-brand">For You</span>
      <div className="nav-links">
        {SECTIONS.map((s) => (
          <button key={s.id} onClick={() => scrollTo(s.id)}>
            {s.label}
          </button>
        ))}
      </div>
    </nav>
  )
}
