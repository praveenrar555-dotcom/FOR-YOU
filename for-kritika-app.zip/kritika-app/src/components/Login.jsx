import { useState } from 'react'
import { LOGIN } from '../content.js'

export default function Login({ onSuccess }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    if (username.trim() === LOGIN.username && password === LOGIN.password) {
      localStorage.setItem('fk_authed', 'true')
      setError('')
      onSuccess()
    } else {
      setError('Kuch match nahi hua, dobara try karo')
    }
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <p className="login-eyebrow">ek chhota sa darwaaza</p>
        <h1>Yeh jagah sirf tumhare liye hai</h1>
        <form onSubmit={handleSubmit}>
          <label>
            Username
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoFocus
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          {error && <p className="login-error">{error}</p>}
          <button type="submit">Andar aao</button>
        </form>
      </div>
    </div>
  )
}
