import { useState } from 'react'
import { QUIZ } from '../content.js'

export default function Quiz() {
  const [answers, setAnswers] = useState({})
  const [submitted, setSubmitted] = useState(false)

  function selectAnswer(qIndex, oIndex) {
    setAnswers({ ...answers, [qIndex]: oIndex })
  }

  const score = QUIZ.reduce(
    (acc, q, i) => acc + (answers[i] === q.correctIndex ? 1 : 0),
    0
  )

  return (
    <section className="section section-dark" id="quiz">
      <p className="section-eyebrow">Quiz</p>
      <h2>Kitna jaanti ho mujhe?</h2>
      {QUIZ.map((q, qi) => (
        <div className="quiz-question" key={qi}>
          <p>{q.question}</p>
          <div className="quiz-options">
            {q.options.map((opt, oi) => (
              <button
                key={oi}
                className={`quiz-option ${answers[qi] === oi ? 'is-selected' : ''}`}
                onClick={() => selectAnswer(qi, oi)}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      ))}
      <button className="quiz-submit" onClick={() => setSubmitted(true)}>
        Result dikhao
      </button>
      {submitted && (
        <p className="quiz-result">
          Tumne {score} / {QUIZ.length} sahi kiye 💖
        </p>
      )}
    </section>
  )
}
