import { useState } from 'react'

const MESSAGES = [
  "Tum meri sabse pyari surprise ho.",
  "Aaj bhi utna hi pyaar karta hu jitna pehle din.",
  "Tumhari hasi mera favorite sound hai.",
  "Thoda ruko... aur bas smile karo, bas itna hi karna tha.",
]

export default function Surprise() {
  const [message, setMessage] = useState(null)
  const [hearts, setHearts] = useState([])

  function trigger() {
    setMessage(MESSAGES[Math.floor(Math.random() * MESSAGES.length)])
    const newHearts = Array.from({ length: 12 }, (_, i) => ({
      id: Date.now() + i,
      left: Math.random() * 100,
      delay: Math.random() * 0.6,
    }))
    setHearts(newHearts)
    setTimeout(() => setHearts([]), 2500)
  }

  return (
    <section className="section section-blush surprise-section" id="surprise">
      <p className="section-eyebrow">Bas Ek Click</p>
      <h2>Yahan click karo</h2>
      <button className="surprise-button" onClick={trigger}>
        Click karo
      </button>
      {message && <p className="surprise-message">{message}</p>}
      <div className="hearts-layer">
        {hearts.map((h) => (
          <span
            key={h.id}
            className="floating-heart"
            style={{ left: `${h.left}%`, animationDelay: `${h.delay}s` }}
          >
            ♥
          </span>
        ))}
      </div>
    </section>
  )
}
