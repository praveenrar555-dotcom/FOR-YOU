import { TIMELINE } from '../content.js'

export default function Timeline() {
  return (
    <section className="section section-dark" id="timeline">
      <p className="section-eyebrow">Hamari Kahani</p>
      <h2>Ab tak ka safar</h2>
      <div className="timeline">
        {TIMELINE.map((item, i) => (
          <div className="timeline-item" key={i}>
            <div className="timeline-marker" />
            <div className="timeline-content">
              <p className="timeline-date">{item.date}</p>
              <p className="timeline-text">{item.text}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
