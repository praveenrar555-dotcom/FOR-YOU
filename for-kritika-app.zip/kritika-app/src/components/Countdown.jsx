import { useEffect, useState } from 'react'
import { COUNTDOWN } from '../content.js'

function getTimeLeft() {
  const diff = new Date(COUNTDOWN.targetDate).getTime() - Date.now()
  if (diff <= 0) return null
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24)
  const minutes = Math.floor((diff / (1000 * 60)) % 60)
  const seconds = Math.floor((diff / 1000) % 60)
  return { days, hours, minutes, seconds }
}

export default function Countdown() {
  const [time, setTime] = useState(getTimeLeft())

  useEffect(() => {
    const id = setInterval(() => setTime(getTimeLeft()), 1000)
    return () => clearInterval(id)
  }, [])

  return (
    <section className="section section-blush" id="countdown">
      <p className="section-eyebrow">Countdown</p>
      <h2>{COUNTDOWN.label}</h2>
      {time ? (
        <div className="countdown-grid">
          <div><span>{time.days}</span><small>din</small></div>
          <div><span>{time.hours}</span><small>ghante</small></div>
          <div><span>{time.minutes}</span><small>minute</small></div>
          <div><span>{time.seconds}</span><small>second</small></div>
        </div>
      ) : (
        <p>Waqt aa gaya hai 💫</p>
      )}
    </section>
  )
}
