import { useState } from 'react'
import { REASONS } from '../content.js'

export default function ReasonsJar() {
  const [reason, setReason] = useState(null)

  function pickReason() {
    const r = REASONS[Math.floor(Math.random() * REASONS.length)]
    setReason(r)
  }

  return (
    <section className="section section-blush" id="reasons">
      <p className="section-eyebrow">Reasons Jar</p>
      <h2>Ek reason nikalo</h2>
      <button className="jar-button" onClick={pickReason}>
        Jar se ek reason nikalo
      </button>
      {reason && <p className="reason-reveal">{reason}</p>}
    </section>
  )
}
