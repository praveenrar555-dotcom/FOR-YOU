import { GALLERY } from '../content.js'

export default function Gallery() {
  return (
    <section className="section section-dark" id="gallery">
      <p className="section-eyebrow">Gallery</p>
      <h2>Kuch pal, kuch tasveerein</h2>
      {GALLERY.length === 0 ? (
        <p className="gallery-empty">
          Apni photos content.js ke GALLERY array mein add karo, yahan dikhengi.
        </p>
      ) : (
        <div className="gallery-grid">
          {GALLERY.map((item, i) => (
            <figure key={i} className="gallery-item">
              <img src={item.src} alt={item.caption} />
              <figcaption>{item.caption}</figcaption>
            </figure>
          ))}
        </div>
      )}
    </section>
  )
}
