import { useEffect, useState } from 'react'
import Login from './components/Login.jsx'
import Nav from './components/Nav.jsx'
import Timeline from './components/Timeline.jsx'
import Letters from './components/Letters.jsx'
import ReasonsJar from './components/ReasonsJar.jsx'
import Gallery from './components/Gallery.jsx'
import Quiz from './components/Quiz.jsx'
import Countdown from './components/Countdown.jsx'
import FuturePlans from './components/FuturePlans.jsx'
import Surprise from './components/Surprise.jsx'
import { PARTNER_NAME } from './content.js'

export default function App() {
  const [authed, setAuthed] = useState(false)

  useEffect(() => {
    if (localStorage.getItem('fk_authed') === 'true') {
      setAuthed(true)
    }
  }, [])

  if (!authed) {
    return <Login onSuccess={() => setAuthed(true)} />
  }

  return (
    <div className="app-shell">
      <Nav />
      <header className="hero">
        <p className="hero-eyebrow">Ek chhoti si duniya, sirf {PARTNER_NAME} ke liye</p>
        <h1>Har scroll ke saath, thoda aur pyaar</h1>
      </header>
      <Timeline />
      <Letters />
      <ReasonsJar />
      <Gallery />
      <Quiz />
      <Countdown />
      <FuturePlans />
      <Surprise />
      <footer className="app-footer">
        <p>Banaya gaya, dil se. 💌</p>
      </footer>
    </div>
  )
}
